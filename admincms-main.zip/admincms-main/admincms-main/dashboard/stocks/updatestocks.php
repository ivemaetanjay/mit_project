<div id="layoutSidenav_content">
        <?php 
            require_once $_SERVER['DOCUMENT_ROOT'] . '/helpers/stockHelper.php';
            $listing = productList([]);
        ?>
        <main>
            <div class="container-fluid px-4">
                <div class="row justify-content-between mt-4 mb-4">
                    <div class="col">
                        <h2 class="mt-4 mb-4">Update Stocks</h2>
                    </div>
                    <div class="col pt-4">
                        <a href="/dashboard/stocks/create.php" type="button" class="btn btn-primary">Create</a>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-header">
                        List
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    foreach($listing as $product) {
                                        $lowStockClass = $product->quantity <= 10 ? 'text-danger' : '';
                                        echo '<tr>';
                                        echo '<th scope="row">' . $product->product_id . '</th>';
                                        echo '<td>' . $product->product_name . '</td>';
                                        echo '<td>' . $product->category . '</td>';
                                        echo "<td><div class=\"{$lowStockClass}\">" . $product->quantity . '</div></td>';
                                        echo "
                                        <td>
                                            <button type=\"button\" class=\"btn btn-secondary\" data-bs-toggle=\"modal\" data-bs-target=\"#stockInModal{$product->product_id}\">Stock In</button>
                                            <button type=\"button\" class=\"btn btn-warning\" data-bs-toggle=\"modal\" data-bs-target=\"#stockOutModal{$product->product_id}\">Stock Out</button>
                                        </td>";
                                        echo '</tr>';
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal for Stock In and Stock Out for each product -->
    <?php foreach($listing as $product) { ?>
        <!-- Modal for Stock In -->
        <div class="modal fade" id="stockInModal<?php echo $product->product_id; ?>" tabindex="-1" role="dialog" aria-labelledby="stockInModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Stock In</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Add your Stock In form content here -->
                        <form action="/dashboard/stocks/stockin.php" method="POST">
                            <!-- Form fields for Stock In -->
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" form="stockInForm<?php echo $product->product_id; ?>" class="btn btn-primary">Stock In</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal for Stock Out -->
        <div class="modal fade" id="stockOutModal<?php echo $product->product_id; ?>" tabindex="-1" role="dialog" aria-labelledby="stockOutModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Stock Out</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Add your Stock Out form content here -->
                        <form action="/dashboard/stocks/stockout.php" method="POST">
                            <!-- Form fields for Stock Out -->
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" form="stockOutForm<?php echo $product->product_id; ?>" class="btn btn-warning">Stock Out</button>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>