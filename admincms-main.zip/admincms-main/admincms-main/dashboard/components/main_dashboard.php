<div id="layoutSidenav_content">

<style>
    .bargraph {
      width: 1500px;
      height: 450px;
      margin: 20px; 
      padding: 10px; 
      background-color: #212529;
    }
  </style>

<div class="bargraph" id="barchart_material"></div>
   
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Stock In', 'Stock Out',],
          ['2014',  400, 200],
          ['2015',  460, 250],
          ['2016',  420, 300],
          ['2017',  540, 350]
        ]);

        var options = {
          chart: {
            title: 'Stock In and Out Data',
            subtitle: 'Stock In and Out Data: 2014-2017',
          },
          bars: 'horizontal' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>

</div>