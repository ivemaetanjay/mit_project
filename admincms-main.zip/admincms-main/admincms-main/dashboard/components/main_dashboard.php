<div id="layoutSidenav_content">

 
     <style>
        .bargraph {
            width: 1600px;
            height: 350px;
            margin: 40px;
            padding: 10px;
            background-color: rgba(33, 37, 41, 0.7);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); 
       
        }
    </style>

<div class="bargraph" id="barchart_material"></div>

<script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Stock In', 'Stock Out',],
          ['2023',  400, 200],
          ['2022',  460, 250],
          ['2021',  420, 300],
          ['2020  ',  540, 350]
        ]);

        var options = {
          chart: {
            title: 'Stock In and Out Data',
            subtitle: 'Stock In and Out Data: 2014-2017',
          },
          bars: 'horizontal' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>


  
    <style>
        .axeschart {
            width: 100%;
            height: 450px;  
                   }
    </style>
       <div class="axeschart"  id='myDiv'></div>

    <script type="text/javascript">

          d3.csv("https://raw.githubusercontent.com/plotly/datasets/master/finance-charts-apple.csv", function(err, rows){
          function unpack(rows, key) {
          return rows.map(function(row) { return row[key]; });
          }

               var x = unpack(rows, 'Date')
               var y = unpack(rows, 'AAPL.Volume')

              var trace = {
                type: "scatter",
                mode: "lines",
                name: 'AAPL Volume',
                x: x,
                y: y,
                line: {color: 'green'},
               }

              var data = [trace];

              var layout = {
                 title: 'Stocks Data Overview ',
                 xaxis: {
                 title: 'Quantity',
                 titlefont: {
                 family: 'Arial, sans-serif',
                 size: 18,
                 color: 'black'
              },
                 showticklabels: true,
                 tickangle: 'auto',
                 tickfont: {
                 family: 'Old Standard TT, serif',
                 size: 14,
                 color: 'grey'
            },
                exponentformat: 'e',
                showexponent: 'all'
                        },
               yaxis: {
                  title: 'Month and Year',
                  titlefont: {
                  family: 'Arial, sans-serif',
                  size: 18,
                  color: 'black'
              },
              showticklabels: true,
                 tickangle: 45,
                 tickfont: {
                 family: 'Old Standard TT, serif',
                 size: 14,
                color: 'grey'
             },
              exponentformat: 'e',
              showexponent: 'all'
                     }
};

Plotly.newPlot('myDiv', data, layout);
})

</script>
</div>