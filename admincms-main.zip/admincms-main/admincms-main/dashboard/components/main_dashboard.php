<div id="layoutSidenav_content">

     <!---###################################################################################################--->

          <!---Bar Graph in Stock in and Out--->
          <style>
    .bargraph {
      width: 700px;
      height: 300px;
      margin: 50px;
      padding: 10px;
      background-color: rgba(33, 37, 41, 0.7);
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
      float: left; 
              }
  </style>

<div class="bargraph" id="barchart_material"></div>

<script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Stock In', 'Stock Out',],
          ['2023',  400, 200],
          ['2022',  460, 250],
          ['2021',  420, 300],
          ['2020  ',  540, 350]
        ]);

        var options = {
          chart: {
            title: 'Stock In and Out Data',
            subtitle: 'Stock In and Out Data: 2014-2017',
          },
          bars: 'vertical' 
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>

          <!-------End Of Bargraph------->
    <!---######################################################################################################--->

          <!----Start of Productgraph---->
          
    <style>
      .productgraph {
      width: 700px;
      height: 300px;
      float: right; 
      margin-right: 40px; 
      margin-top: 40px;
    }
    </style>
    
<div class="productgraph" id="chart_div" ></div>

<script type="text/javascript">

      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Bolivia', 'Ecuador', 'Madagascar', 'Papua New Guinea', 'Rwanda', 'Average'],
          ['2004/05',  165,      938,         522,             998,           450,      614.6],
          ['2005/06',  135,      1120,        599,             1268,          288,      682],
          ['2006/07',  157,      1167,        587,             807,           397,      623],
          ['2007/08',  139,      1110,        615,             968,           215,      609.4],
          ['2008/09',  136,      691,         629,             1026,          366,      569.6]
        ]);

        var options = {
          title : 'Product Overview',
          vAxis: {title: 'Quantity'},
          hAxis: {title: 'Month'},
          seriesType: 'bars',
          series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
      </script>


           <!----End Of the Productgraph---->
   <!---#########################################################################################################--->

        <!---Graphical Chart in All Product--->
    <style>
        .axeschart {
            width: 100%;
            height: 450px;  
                   }
    </style>
       <div class="axeschart"  id='myDiv'></div>

    <script type="text/javascript">

          d3.csv("https://raw.githubusercontent.com/plotly/datasets/master/finance-charts-apple.csv", function(err, rows){
          function unpack(rows, key) {
          return rows.map(function(row) { return row[key]; });
          }

               var x = unpack(rows, 'Date')
               var y = unpack(rows, 'AAPL.Volume')

              var trace = {
                type: "scatter",
                mode: "lines",
                name: 'AAPL Volume',
                x: x,
                y: y,
                line: {color: 'green'},
               }

              var data = [trace];

              var layout = {
                 title: 'Stocks Data Overview ',
                 xaxis: {
                 title: 'Month and Year',
                 titlefont: {
                 family: 'Arial, sans-serif',
                 size: 18,
                 color: 'black'
              },
                 showticklabels: true,
                 tickangle: 'auto',
                 tickfont: {
                 family: 'Old Standard TT, serif',
                 size: 14,
                 color: 'grey'
            },
                exponentformat: 'e',
                showexponent: 'all'
                        },
               yaxis: {
                  title: 'Quantity',
                  titlefont: {
                  family: 'Arial, sans-serif',
                  size: 18,
                  color: 'black'
              },
              showticklabels: true,
                 tickangle: 45,
                 tickfont: {
                 family: 'Old Standard TT, serif',
                 size: 14,
                color: 'grey'
             },
              exponentformat: 'e',
              showexponent: 'all'
                     }
};

Plotly.newPlot('myDiv', data, layout);
})

</script>
</div>