<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard Simsa</title>
    <link href="/css/styles.css" rel="stylesheet" />
    <script src="/js/all.js" crossorigin="anonymous"></script>

    <!---Bar Chart Libraries--->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  

    <!--Graphical Chart Libraries--->
    <script src='https://cdn.plot.ly/plotly-2.26.0.min.js'></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.17/d3.min.js'></script>

    <!-- Modal Bootstrap for stock  in and out style-->
    <style>
        /* Customize the modal dialog for both Stock In and Stock Out modals */
        .modal-dialog {
            max-width: 600px; /* Adjust the maximum width of the modal dialog */
        }

        /* Customize the modal content for both Stock In and Stock Out modals */
        .modal-content {
            border-radius: 10px; /* Add rounded corners to the modal */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Add a shadow to the modal */
            background-color: rgba(255, 255, 255, 0.4);
        }

        /* Customize the modal header for both Stock In and Stock Out modals */
        .modal-header {
            background-color: #343a40; /* Change the header background color */
            color: #fff; /* Change the header text color */
            
        }

        /* Customize the modal title for both Stock In and Stock Out modals */
        .modal-title {
            font-weight: bold; /* Make the title text bold */
        }

        /* Customize the modal body for both Stock In and Stock Out modals */
        .modal-body {
            padding: 30px; /* Add padding to the modal body */
         
        }

        /* Customize the form inputs within the modal body */
        .modal-body input {
            width: 100%; /* Make the form inputs stretch to the full width of the modal body */
            margin-bottom: 20px; /* Add some spacing between form elements */
            background-color: rgba(255, 255, 255, 0.5);
        }
    </style>
    

</head>
<body class="sb-nav-fixed">
<div id="layoutSidenav">

<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';
    // config.php must be first in the sequence of importing
    require_once $_SERVER['DOCUMENT_ROOT'] . '/helpers/functions.php';
    // functions.php must be first in the sequence of importing
    require_once $_SERVER['DOCUMENT_ROOT'] . '/helpers/auth.php';

    if (!isAuthenticated()) {
        header('location: ' . '/login.php');
    }
?>