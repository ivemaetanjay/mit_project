<?php

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'simsa');
define('DB_USER', 'root');
define('DB_PASSWORD', 'password');
define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT']);
define('DASHBOARD_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'] . '/dashboard');
?>
