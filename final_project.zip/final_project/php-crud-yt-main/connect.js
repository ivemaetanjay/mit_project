// Get references to form elements
const loginForm = document.querySelector('.sign-in form');
const registerForm = document.querySelector('.sign-up form');

// Handle login form submission
loginForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const username = document.getElementById('user').value;
  const password = document.getElementById('pass').value;

  // Implement your authentication logic here (e.g., check credentials)
  // For demonstration purposes, we'll just store the username in localStorage
  localStorage.setItem('loggedInUser', username);

  // Redirect to another page (replace 'dashboard.html' with your desired destination)
  window.location.href = 'index.php';
});

// Handle registration form submission
registerForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Implement your registration logic here (e.g., create a new user)
  // For demonstration purposes, we'll just store the username in localStorage
  localStorage.setItem('registeredUser', username);

  // Redirect to another page (replace 'dashboard.html' with your desired destination)
  window.location.href = 'login.php';
});
