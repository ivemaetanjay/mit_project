<?php include_once($_SERVER['DOCUMENT_ROOT'] . '/dashboard/layouts/header.php') ?>
<?php include_once(DASHBOARD_ROOT_PATH . '/layouts/topnav.php') ?>
<?php include_once(DASHBOARD_ROOT_PATH . '/layouts/leftnav.php') ?>

<!-- main content here -->
<?php include_once(DASHBOARD_ROOT_PATH . '/history/components/listing.php') ?>

<?php include_once(DASHBOARD_ROOT_PATH . '/layouts/footer.php') ?>