-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2023 at 05:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simsa`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `quantity`, `category`, `created_at`, `updated_at`) VALUES
(19, 'patatas', 180, 'kitchen', '2023-10-22', '2023-01-03'),
(20, 'onion', 52, 'kitchen', '2023-10-22', '2023-01-03'),
(21, 'shrimp', 176, 'kitchen', '2023-10-22', '2023-01-03'),
(22, 'calamares', 18, 'kitchen', '2023-10-22', '2023-01-03'),
(23, 'fish fillet', 41, 'kitchen', '2023-10-22', '2023-01-03'),
(24, 'carrots', 27, 'kitchen', '2023-10-22', '2023-01-03'),
(25, 'UFC ketchup', 60, 'kitchen', '2023-10-22', '2023-01-03'),
(26, 'sprite', 122, 'kitchen', '2023-10-22', '2023-01-03'),
(27, 'coke', 37, 'kitchen', '2023-10-22', '2023-01-03'),
(28, 'royal', 96, 'drinks', '2023-10-22', '2022-01-01'),
(29, 'dahonan', 160, 'kitchen', '2023-02-03', '2023-11-03'),
(30, 'sisig', 10, 'kitchen', '2023-11-03', '2023-11-03');

-- --------------------------------------------------------

--
-- Table structure for table `product_logs`
--

CREATE TABLE `product_logs` (
  `id` int(11) NOT NULL,
  `mode` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_logs`
--

INSERT INTO `product_logs` (`id`, `mode`, `quantity`, `product_id`, `created_at`) VALUES
(15, 'in', 33, 27, '2023-10-22'),
(16, 'in', 22, 26, '2023-10-22'),
(17, 'in', 11, 28, '2023-10-22'),
(18, 'out', 11, 20, '2023-10-22'),
(19, 'in', 23, 19, '2023-10-23'),
(20, 'out', 90, 19, '2023-10-23'),
(21, 'in', 32, 20, '2023-10-23'),
(22, 'in', 20, 20, '2023-10-23'),
(23, 'in', 77, 19, '2023-10-23'),
(24, 'in', 20, 27, '2023-10-23'),
(25, 'in', 21, 28, '2023-10-23'),
(26, 'in', 21, 27, '2023-10-23'),
(27, 'in', 50, 19, '2023-10-23'),
(28, 'out', 90, 19, '2023-10-23'),
(29, 'in', 93, 19, '2022-01-01'),
(30, 'out', 115, 19, '2022-01-01'),
(31, 'in', 69, 20, '2022-01-01'),
(32, 'out', 75, 20, '2022-01-01'),
(33, 'in', 73, 21, '2022-01-01'),
(34, 'out', 123, 21, '2022-01-01'),
(35, 'in', 71, 22, '2022-01-01'),
(36, 'out', 97, 22, '2022-01-01'),
(37, 'in', 49, 24, '2022-01-01'),
(38, 'in', 64, 28, '2022-01-01'),
(39, 'in', 51, 26, '2022-01-01'),
(40, 'in', 24, 25, '2022-01-01'),
(41, 'in', 95, 24, '2022-01-01'),
(42, 'out', 12, 24, '2022-01-01'),
(43, 'out', 10, 28, '2022-01-01'),
(44, 'in', 30, 19, '2022-01-01'),
(45, 'in', 30, 21, '2022-01-01'),
(46, 'in', 50, 21, '2022-01-01'),
(47, 'in', 120, 22, '2022-01-01'),
(48, 'in', 20, 19, '2022-02-03'),
(49, 'out', 100, 19, '2022-02-03'),
(50, 'in', 41, 20, '2022-02-03'),
(51, 'out', 78, 20, '2022-02-03'),
(52, 'in', 78, 21, '2022-02-03'),
(53, 'out', 120, 21, '2022-02-03'),
(54, 'in', 44, 23, '2022-02-03'),
(55, 'in', 24, 19, '2023-02-03'),
(56, 'out', 10, 19, '2023-02-03'),
(57, 'in', 66, 20, '2023-02-03'),
(58, 'out', 41, 20, '2023-02-03'),
(59, 'in', 121, 21, '2023-02-03'),
(60, 'out', 30, 21, '2023-02-03'),
(61, 'out', 120, 22, '2023-02-03'),
(62, 'out', 38, 23, '2023-02-03'),
(63, 'out', 130, 24, '2023-02-03'),
(64, 'out', 10, 25, '2023-02-03'),
(65, 'in', 64, 26, '2023-11-03'),
(66, 'in', 40, 22, '2023-11-03'),
(67, 'out', 10, 29, '2023-11-03'),
(68, 'in', 50, 29, '2023-11-03'),
(69, 'in', 35, 19, '2023-11-03'),
(70, 'out', 20, 19, '2023-11-03'),
(71, 'in', 10, 20, '2023-11-03'),
(72, 'out', 20, 20, '2023-11-03'),
(73, 'in', 12, 21, '2023-11-03'),
(74, 'out', 50, 21, '2023-11-03'),
(75, 'in', 10, 21, '2023-11-03'),
(76, 'in', 44, 25, '2023-11-03'),
(77, 'in', 50, 19, '2023-01-03'),
(78, 'out', 10, 19, '2023-01-03'),
(79, 'in', 41, 20, '2023-01-03'),
(80, 'out', 30, 20, '2023-01-03'),
(81, 'in', 20, 21, '2023-01-03'),
(82, 'out', 50, 21, '2023-01-03'),
(83, 'in', 20, 22, '2023-01-03'),
(84, 'out', 50, 22, '2023-01-03'),
(85, 'in', 10, 23, '2023-01-03'),
(86, 'out', 20, 23, '2023-01-03'),
(87, 'in', 30, 24, '2023-01-03'),
(88, 'out', 40, 24, '2023-01-03'),
(89, 'in', 10, 25, '2023-01-03'),
(90, 'out', 30, 25, '2023-01-03'),
(91, 'in', 90, 19, '2023-01-03'),
(92, 'in', 40, 25, '2023-01-03'),
(93, 'out', 20, 25, '2023-01-03'),
(94, 'out', 100, 26, '2023-01-03'),
(95, 'in', 10, 27, '2023-01-03'),
(96, 'out', 80, 27, '2023-01-03'),
(97, 'in', 61, 26, '2023-01-03'),
(98, 'in', 88, 21, '2023-01-03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(100) DEFAULT NULL,
  `access_level` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `phone_number`, `access_level`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', 'password', NULL, 1, NULL, NULL),
(16, 'staff', 'staff', 'user123', '0935461237', 2, '2023-10-23', '2023-10-23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_logs`
--
ALTER TABLE `product_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `product_logs`
--
ALTER TABLE `product_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
